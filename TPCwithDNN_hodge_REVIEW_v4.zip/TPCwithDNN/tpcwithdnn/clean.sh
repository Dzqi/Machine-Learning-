rm validation/*.* plots/*.*
